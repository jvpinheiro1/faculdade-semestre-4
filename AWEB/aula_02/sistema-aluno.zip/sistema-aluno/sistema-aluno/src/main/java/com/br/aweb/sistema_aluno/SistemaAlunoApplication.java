package com.br.aweb.sistema_aluno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaAlunoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaAlunoApplication.class, args);
	}

}
