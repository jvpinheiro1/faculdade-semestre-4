INSERT INTO aluno (name, idade, materia) VALUES 
('Gabriel Cortez', '21', 'Backend'),
('Heloisa vichiatto', '33', 'Design'),
('Joao Vitor Pinheiro Garcia', '34', 'Backend'),
('Gabriel Correa', '33', 'Front'),
('Bruno Duran', '53', 'Front');