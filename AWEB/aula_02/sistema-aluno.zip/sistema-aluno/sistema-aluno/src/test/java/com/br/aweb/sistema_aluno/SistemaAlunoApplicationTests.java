package com.br.aweb.sistema_aluno;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaAlunoApplicationTests {

	@Test
	void contextLoads() {
	}

}
